const request = require('request');
const cheerio = require('cheerio');
var url = require('url');

exports.handler = async (event) => {
    let arrayFiles = [];
    let arrayAux = [];
    let timeout = 120000;
    let url = event.url;
    console.log(new url(url));
    // console.log(new URL(url));

    request(url, {timeout: timeout}, function (error, response, body) {
        if(error){
            console.log('error:\n', error);
        } else {
            const $ = cheerio.load(body);
            console.log('code: ' + response.statusCode);
            
            console.log('====Get all links===');
            
            $( "*" ).each(function() {


                if($(this).attr("src") != undefined){
                    let value = $(this).attr("src");

                    if(value.includes('/js/') ||
                        value.includes('/images/') ||
                        value.includes('/css/')){
                        console.log(value);
                        arrayAux.push(value);
                    }

                } 
                else if($(this).attr("href") != undefined){
                    let value =  $(this).attr("href");

                    if(value.includes('/js/') ||
                        value.includes('/images/') ||
                        value.includes('/css/')){
                        console.log(value);
                        arrayAux.push(value);
                    }
                }
            });

            console.log(arrayAux.length);


            console.log('====Verify links===');


            // Verify statusCode = 200

            arrayAux.forEach(fileUrl => {
                console.log('if: ' + fileUrl);
                if(fileUrl.includes(url)){
                    arrayFiles.push(fileUrl);
                } else {
                    let newUrl = new url(url).origin.concat(fileUrl);
                    console.log('else: ' + newUrl);

                    if(newUrl.includes('https://') || newUrl.includes('http://')){
                        return;
                    }

                    request(newUrl, {timeout: timeout}, function (error, response, body) {
                        if(error){
                            console.log(error);
                            return;
                        }

                        console.log('status code: ' + response.statusCode);
                        if(response.statusCode == 200)
                            arrayFiles.push(newUrl);
                    });
                }
            });


            setTimeout(() => {
                console.log('====Links Verified===');
                arrayFiles.forEach(fileLink => {
                    console.log(fileLink);
                });
    
                console.log(arrayFiles.length);
            }, 5000);

        }
    });
    // TODO implement
    // const response = {
    //     statusCode: 200,
    //     body: JSON.stringify('Hello from Lambda!'),
    // };
    // return response;
};